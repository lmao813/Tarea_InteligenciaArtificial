# Capítulo 1 - Inteligencia Artificial

Este repositorio contiene las respuestas a los ejercicios del Capítulo 1 de la materia de Inteligencia Artificial.

## Contenido

1. Definiciones de IA por varios LLMs.
2. Definición propia de IA.
3. Análisis del video propuesto.
4. Investigación sobre los planes del gobierno en relación con la IA.
