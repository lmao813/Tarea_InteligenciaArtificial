# Capítulo 1 - Inteligencia Artificial

## 1. Definiciones de IA por varios LLMs

### 🔹 ChatGPT (OpenAI):
> "La inteligencia artificial (IA) es un campo de la informática que se centra en la creación de sistemas capaces de realizar tareas que normalmente requieren inteligencia humana, como el reconocimiento de voz, la toma de decisiones y la traducción de idiomas."

### 🔹 Gemini (Google):
> "La IA es la capacidad de una máquina para imitar comportamientos inteligentes humanos, como aprender, razonar, resolver problemas y adaptarse a nuevas situaciones."

### 🔹 Claude (Anthropic):
> "La inteligencia artificial es un conjunto de técnicas computacionales que permiten a las máquinas procesar información, aprender de datos y ejecutar acciones basadas en ese aprendizaje."


## 2. Definición propia de IA

> "La inteligencia artificial es la capacidad de un sistema computacional de analizar datos, aprender patrones y ejecutar tareas complejas que tradicionalmente requerirían razonamiento o decisión humana."


## 3. Análisis del video propuesto

🔗 Video: [¿Qué es la inteligencia artificial? – YouTube](https://www.youtube.com/watch?v=JsmKUCiPHUY&t=7s)

El video explica que la inteligencia artificial permite a las máquinas simular procesos de la inteligencia humana como el aprendizaje, el razonamiento y la percepción. Se mencionan ejemplos prácticos como asistentes virtuales, automóviles autónomos y sistemas de recomendación.

En relación con lo discutido en el capítulo 1 del curso, el video refuerza que la IA no es una única tecnología sino una combinación de técnicas como el aprendizaje automático, la lógica difusa y las redes neuronales. Ambos resaltan que la IA puede aprender de la experiencia (datos) y ajustarse a nuevas entradas para realizar tareas humanas con eficiencia.

El video aporta claridad visual y ejemplos accesibles, mientras que el capítulo posiblemente se enfoca más en definiciones técnicas y fundamentos históricos.


## 4. Investigación sobre los planes del gobierno respecto a la IA

El gobierno colombiano presentó en 2019 la **Política Nacional para la IA (MINTIC y DNP)**, con el objetivo de impulsar el desarrollo de sistemas inteligentes que mejoren el bienestar social y la competitividad del país.

Esta política incluye:

- Uso de IA en salud, educación, justicia y medio ambiente.
- Promoción de talento digital en IA.
- Ética y gobernanza para el desarrollo responsable de la IA.
- Uso de datos abiertos y seguros para entrenamiento de modelos.

Colombia también hace parte de iniciativas globales como la **Alianza Global sobre la Inteligencia Artificial (GPAI)**.

Fuentes:
- https://mintic.gov.co/portal/inicio/Secciones-de-Interes/Inteligencia-Artificial/
- https://colaboracion.dnp.gov.co/CDT/Conpes/Econ%C3%B3micos/3975.pdf
